import java.util.Random;

public class MagicalArenaGame {
    public static void main(String[] args) throws Exception {
        int healthA = 10;
        int strengthA = 10;
        int attackA = 5;
        int healthB = 50;
        int strengthB = 5;
        int attackB = 10;

        System.out.println(
                "Player A's initial Health: " + healthA + ", Strength: " + strengthA + ", Attacks: " + attackA);
        System.out.println(
                "Player B's initial Health: " + healthB + ", Strength: " + strengthB + ", Attacks: " + attackB);

        String whoWillStartFirst = healthA > healthB ? "Player A will attacks first"
                : "Player B will attacks first";
        System.out.println(whoWillStartFirst);

        Player playerA = new Player("Player A", healthA, strengthA, attackA);
        Player playerB = new Player("Player B", healthB, strengthB, attackB);
        MagicalArena arena = new MagicalArena(playerA, playerB);
        arena.startMatch();
    }
}

class Player {
    private String name;
    private int health;
    private int strength;
    private int attack;

    public Player(String name, int health, int strength, int attack) {
        this.name = name;
        this.health = health;
        this.strength = strength;
        this.attack = attack;
    }

    //getters and setters
    public int getHealth() {
        return health;
    }

    public int getStrength() {
        return strength;
    }

    public int getAttack() {
        return attack;
    }

    public void reduceHealth(int damage) {
        health -= damage;
        if (health < 0) {
            health = 0;
        }
    }

    public boolean isHealthGreaterZero() {
        return health > 0;
    }

    public int rollDice() {
        Random rand = new Random();
        return rand.nextInt(6) + 1;
    }

    public String getName() {
        return name;
    }
}

class MagicalArena {
    private Player playerA;
    private Player playerB;

    public MagicalArena(Player playerA, Player playerB) {
        this.playerA = playerA;
        this.playerB = playerB;
    }

    public void startMatch() {
        Player attacker;
        Player defender;

        while (playerA.isHealthGreaterZero() && playerB.isHealthGreaterZero()) {
            // Determine initial attacker and defender based on current health
            if (playerA.getHealth() < playerB.getHealth()) {
                attacker = playerA;
                defender = playerB;
            } else {
                attacker = playerB;
                defender = playerA;
            }

            int attackerRoll = attacker.rollDice();
            System.out.println(attacker.getName() + "'s dice number: " + attackerRoll);

            int defenderRoll = defender.rollDice();
            System.out.println(defender.getName() + "'s dice number: " + defenderRoll);

            int attackDamage = attacker.getAttack() * attackerRoll;
            int defendStrength = defender.getStrength() * defenderRoll;

            int damageTaken = Math.abs(attackDamage - defendStrength);
            defender.reduceHealth(damageTaken);

            String defenderReducesHealth = attackDamage == defendStrength
                    ? " " + defender.getName() + "'s health will not reduce at this point"
                    : " " + defender.getName() + "'s health reduced by: " + damageTaken;
            System.out.println(attacker.getName() + "'s damage: " + attackDamage
                    + ", " + defender.getName() + "'s strength: " + defendStrength +
                    defenderReducesHealth);
            System.out.println(attacker.getName() + "'s updated health " +
                    attacker.getHealth());
            System.out.println(defender.getName() + "'s updated health: " +
                    defender.getHealth());

            // Swap roles for the next turn
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        // Determine the winner
        if (playerA.isHealthGreaterZero()) {
            System.out.println("Player A wins!");
        } else {
            System.out.println("Player B wins!");
        }
    }
}
