import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class MagicalArenaTest {

    @Test
    public void testPlayerHealthReduction() {
        Player playerA = new Player("Player A", 50, 10, 5);
        Player playerB = new Player("Player B", 50, 5, 10);
        
        int initialHealth = playerB.getHealth();
        playerA.reduceHealth(20);
        assertEquals(initialHealth - 20, playerA.getHealth());
    }

    @Test
    public void testPlayerIsAlive() {
        Player playerA = new Player("Player A", 50, 10, 5);
        assertTrue(playerA.isHealthGreaterZero());

        playerA.reduceHealth(55);
        assertFalse(playerA.isHealthGreaterZero());
    }

    @Test
    public void testPlayerRollDice() {
        Player playerA = new Player("Player A", 50, 10, 5);
        int diceRoll = playerA.rollDice();
        assertTrue(diceRoll >= 1 && diceRoll <= 6);
    }

    @Test
    public void testMagicalArenaStartMatch() {
        Player playerA = new Player("Player A", 50, 10, 5);
        Player playerB = new Player("Player B", 50, 5, 10);
        MagicalArena arena = new MagicalArena(playerA, playerB);

        arena.startMatch();

        assertFalse(playerA.isHealthGreaterZero() && playerB.isHealthGreaterZero());
    }
}


