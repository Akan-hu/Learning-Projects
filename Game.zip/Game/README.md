## Getting Started


Usage
# To run the program, execute the Main class MagicalArenaGame This class initializes two players with their respective attributes and starts the match in the magical arena.

Magical Arena
 # This Java program simulates a magical arena where players engage in battles. Each player is defined by their health, strength, and attack attributes. The game ends when one player's health reaches zero.

Player Class
 # The Player class represents a player in the arena. It has the following attributes:

# health: The player's health points.
# strength: The player's strength attribute.
# attack: The player's attack attribute.
# The class provides methods to access these attributes, reduce the player's health, check if the player is alive, and roll a dice for attacking.

MagicalArena Class
# The MagicalArena class orchestrates the matches between players. It takes two Player objects as input and simulates the battle between them. The match starts with the player having lower health attacking first.

# During each turn, the attacking player rolls a dice to determine the attack strength, and the defending player rolls a dice to determine the defense strength. Damage is calculated based on the attack and defense strengths, and the defender's health is reduced accordingly.

# The match continues until one of the players' health reaches zero. The winner is then declared.

Getting commit history
# git log


To test code
# clicks on testing icon in vscode in left (below extension icon)
# Clicks on run icon of folder Game
